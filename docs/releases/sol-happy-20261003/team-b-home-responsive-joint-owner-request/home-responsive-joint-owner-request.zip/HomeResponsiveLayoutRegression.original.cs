using System.Reflection;
using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Headless;
using Avalonia.VisualTree;
using CakeOS.Cui.Language;
using CakeOS.Cui.Runtime;
using NineToOne.Web;

// Actual production Render and unchanged owner bindings; intrinsic-flow proposal is evidence-only.
// No browser/runtime/rendered readability acceptance; optional disabled scroll
// is an explicitly diagnostic native property change, never shipped acceptance.
if (args.Length != 5) throw new ArgumentException("Home.cui output.json width height production|disable-horizontal-diagnostic");
var sourcePath = Path.GetFullPath(args[0]);
var outputPath = Path.GetFullPath(args[1]);
var width = double.Parse(args[2], System.Globalization.CultureInfo.InvariantCulture);
var height = double.Parse(args[3], System.Globalization.CultureInfo.InvariantCulture);
var diagnostic = args[4] == "disable-horizontal-diagnostic";
if (args[4] != "production" && !diagnostic) throw new ArgumentException("Unknown diagnostic mode.");
if (!double.IsFinite(width) || !double.IsFinite(height) || width <= 0 || height <= 0) throw new ArgumentException("Finite positive dimensions required.");
await using var session = HeadlessUnitTestSession.StartNew(typeof(HomeResponsiveApplication));
var failures = await session.Dispatch(() =>
{
    var parser = new CuiRichParser();
    var document = parser.Parse(File.ReadAllText(sourcePath), sourcePath);
    if (parser.Diagnostics.Diagnostics.Any(d => d.Severity == CuiDiagnosticSeverity.Error)) throw new InvalidDataException("Canonical Home parse failed.");
    var bindings = new BrowserHomeContext(document, _ => throw new InvalidOperationException("This glyph probe does not navigate or invent service actions."));
    if (!bindings.Open(new("home.dashboard"))) throw new InvalidOperationException("Actual unavailable Home context did not open dashboard.");
    var app = new BrowserApplication();
    var view = (ContentControl)typeof(BrowserApplication).GetField("_view", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(app)!;
    var render = typeof(BrowserApplication).GetMethod("Render", BindingFlags.NonPublic | BindingFlags.Instance)!;
    var window = new Window { Content = view, Width = width, Height = height };
    window.Show();
    try
    {
        if (render.Invoke(app, [new BrowserCuiSurface(document, bindings, bindings), "#/home.dashboard"]) is not true)
            throw new InvalidOperationException("Actual BrowserApplication.Render failed.");
        var scroll = (ScrollViewer)view.Content!;
        if (diagnostic) scroll.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        using var frame = window.CaptureRenderedFrame();
        if (frame is null) throw new InvalidOperationException("Actual native rendered frame unavailable.");
        var root = (Control)scroll.Content!;
        var controls = root.GetVisualDescendants().OfType<Control>().Prepend(root).ToArray();
        Control Named(string name) => controls.Single(c => c.Name == name);
        Rect InRoot(Control control)
        {
            var origin = control.TranslatePoint(default, root) ?? throw new InvalidOperationException("Detached actual native control.");
            return new Rect(origin, control.Bounds.Size);
        }
        var checks = new List<object>();
        var failed = 0;
        void Check(string name, bool passed)
        { checks.Add(new { name, passed }); Console.WriteLine($"{(passed ? "PASS" : "FAIL")}: {name}"); if (!passed) ++failed; }
        var order = new[] { "welcome-heading", "welcome-copy", "dashboard-brief", "home-hero", "operation-status", "navigation-status", "app-shortcuts", "upcoming-events", "dashboard-layout-controls" };
        var sections = order.Select(id => new { id, bounds = InRoot(Named(id)) }).ToArray();
        // Preserve the same original eight section-order assertions.
        foreach (var pair in sections.Zip(sections.Skip(1)))
            Check($"{pair.Second.id} follows {pair.First.id}", pair.Second.bounds.Y + 0.01 >= pair.First.bounds.Bottom);
        const string explanation = "Open a Space, manage your apps, or review what needs attention.";
        var copy = controls.OfType<TextBlock>().Single(text => text.Text == explanation);
        var column = InRoot(Named("observed-status"));
        var bounds = InRoot(copy);
        var layout = copy.TextLayout;
        var glyphs = layout.HitTestTextRange(0, explanation.Length).ToArray();
        if (glyphs.Length == 0) throw new InvalidOperationException("Actual full text glyph range unavailable.");
        var fullRange = layout.TextLines.Sum(line => line.Length) >= explanation.Length;
        Check("Complete hero explanation remains in actual native text layout", fullRange);
        Check("Hero full text range fits its assigned native width", glyphs.All(rect => rect.X >= -0.01 && rect.Right <= copy.Bounds.Width + 0.01));
        var rangeBounds = glyphs.Select(rect => new Rect(bounds.X + copy.Padding.Left + rect.X, bounds.Y + copy.Padding.Top + rect.Y, rect.Width, rect.Height)).ToArray();
        Check("Hero explanatory glyph ranges do not intersect observed-status column", rangeBounds.All(rect => !rect.Intersects(column)));
        var rootBounds = new Rect(root.Bounds.Size);
        Check("Actual hero text remains within measured Home root width", rangeBounds.All(rect => rect.Right <= rootBounds.Right + 0.01));
        // These eight new checks retain the original twelve above unchanged.
        // Diagnostics never certify shipped host reflow or narrow browser use.
        Check("Native client width matches the requested viewport", Math.Abs(window.ClientSize.Width - width) <= 0.01);
        Check("Native scroll viewport width matches native client width", Math.Abs(scroll.Viewport.Width - window.ClientSize.Width) <= 0.01);
        Check("Home native horizontal extent fits the scroll viewport", scroll.Extent.Width <= scroll.Viewport.Width + 0.01);
        Check("Home root fits the native scroll viewport width", root.Bounds.Width <= scroll.Viewport.Width + 0.01);
        var visibleInputs = controls.OfType<TextBox>().Where(input => input.IsEffectivelyVisible).ToArray();
        var visibleButtons = controls.OfType<Button>().Where(button => button.IsEffectivelyVisible).ToArray();
        Check("Actual Home text inputs fit root horizontal bounds", visibleInputs.Length > 0 && visibleInputs.All(input => input.IsMeasureValid && input.IsArrangeValid
            && InRoot(input).X >= -0.01 && InRoot(input).Right <= root.Bounds.Width + 0.01));
        Check("Actual Home buttons fit root horizontal bounds", visibleButtons.Length > 0 && visibleButtons.All(button => button.IsMeasureValid && button.IsArrangeValid
            && InRoot(button).X >= -0.01 && InRoot(button).Right <= root.Bounds.Width + 0.01));
        var textRanges = controls.OfType<TextBlock>().Where(text => text.IsEffectivelyVisible && !string.IsNullOrEmpty(text.Text))
            .Select(text => new { name = text.Name, text = text.Text, bounds = InRoot(text), assignedWidth = text.Bounds.Width,
                measureValid = text.IsMeasureValid, arrangeValid = text.IsArrangeValid,
                completeTextLength = text.TextLayout.TextLines.Sum(line => line.Length),
                wrapping = text.TextWrapping.ToString(), ranges = text.TextLayout.HitTestTextRange(0, text.Text!.Length).ToArray() }).ToArray();
        Check("Every actual Home full text range fits its assigned width", textRanges.Length > 0 && textRanges.All(text => text.measureValid && text.arrangeValid
            && text.ranges.Length > 0 && text.completeTextLength >= text.text!.Length
            && double.IsFinite(text.assignedWidth) && text.assignedWidth > 0
            && text.ranges.All(range => double.IsFinite(range.X) && double.IsFinite(range.Right) && range.X >= -0.01 && range.Right <= text.assignedWidth + 0.01)));
        var hiddenControls = controls.Where(control => !control.IsEffectivelyVisible)
            .Select(control => new { control.Name, type = control.GetType().Name, control.IsVisible, control.IsEffectivelyVisible, control.IsMeasureValid, control.IsArrangeValid }).ToArray();
        var unarrangedVisibleControls = controls.Where(control => control.IsEffectivelyVisible && (!control.IsMeasureValid || !control.IsArrangeValid))
            .Select(control => new { control.Name, type = control.GetType().Name, control.IsMeasureValid, control.IsArrangeValid }).ToArray();
        Check("Actual Home Library Events navigation remains enabled", new[] { "nav-home", "nav-library", "nav-events" }.All(id => Named(id) is Button { IsEnabled: true }));
        var report = new
        {
            scope = "Actual native source-linked BrowserApplication.Render, anonymous existing Home projection and TextLayout geometry; not browser or full visible readability acceptance.",
            sourcePath, width, height, horizontalScroll = scroll.HorizontalScrollBarVisibility.ToString(), diagnosticPropertyMutation = diagnostic,
            checks, failures = failed, sections, textRanges,
            hiddenControls, hiddenControlCount = hiddenControls.Length, unarrangedVisibleControls, unarrangedVisibleControlCount = unarrangedVisibleControls.Length,
            buttons = controls.OfType<Button>().Select(button => new { button.Name, button.Content, button.IsEnabled, button.Tag, bounds = InRoot(button) }).ToArray(),
            inputs = controls.OfType<TextBox>().Select(input => new { input.Name, input.IsEnabled, bounds = InRoot(input) }).ToArray(), nativeClientSize = window.ClientSize, nativeRoot = root.Bounds,
            scrollExtent = scroll.Extent, scrollViewport = scroll.Viewport,
            heroCopy = new { text = copy.Text, wrapping = copy.TextWrapping.ToString(), bounds, nativeWidth = copy.Bounds.Width, clipToBounds = copy.ClipToBounds,
                layoutWidth = layout.WidthIncludingTrailingWhitespace, layoutHeight = layout.Height, lineCount = layout.TextLines.Count, glyphs, rangeBounds },
            observedStatus = column
        };
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        File.WriteAllText(outputPath, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
        return failed;
    }
    finally { app.ResetPrivateContext(); window.Content = null; window.Close(); }
}, CancellationToken.None);
if (failures != 0) throw new InvalidOperationException($"Native Home glyph/layout failed {failures} assertions.");

public sealed class HomeResponsiveApplication : Application
{
    public static AppBuilder BuildAvaloniaApp() => CuiNativeHost.ConfigureFonts(AppBuilder.Configure<HomeResponsiveApplication>().UseSkia())
        .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false });
    public override void Initialize() => CuiNativeHost.InitialisePrimitiveTheme(this, "Home");
}
