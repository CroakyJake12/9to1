#!/usr/bin/env python3
"""Select an independently pinned source cohort for the unchanged bounded native20 runner."""
import argparse,hashlib,importlib.util,pathlib,sys
p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--expected-manifest-sha256',required=True);p.add_argument('--output',required=True)
p.add_argument('--build-deadline',type=float,default=1800);p.add_argument('--cohort-deadline',type=float,default=180);a=p.parse_args()
runner=pathlib.Path(__file__).with_name('run-native20-cohorts.py')
if hashlib.sha256(runner.read_bytes()).hexdigest()!='11964712f31865135025ba918a48db29671e1139245515425bb21b9152f4f349':raise SystemExit('Frozen bounded runner changed.')
manifest=pathlib.Path(a.manifest)
if not manifest.is_absolute() or len(a.expected_manifest_sha256)!=64 or any(c not in '0123456789abcdef' for c in a.expected_manifest_sha256):raise SystemExit('Explicit absolute manifest and lowercase SHA256 required.')
if hashlib.sha256(manifest.read_bytes()).hexdigest()!=a.expected_manifest_sha256:raise SystemExit('Source cohort receipt SHA mismatch.')
spec=importlib.util.spec_from_file_location('native20_runner',runner);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.MANIFEST=manifest;module.EXPECTED=a.expected_manifest_sha256
sys.argv=[str(runner),'--output',a.output,'--build-deadline',str(a.build_deadline),'--cohort-deadline',str(a.cohort_deadline)]
raise SystemExit(module.main())
