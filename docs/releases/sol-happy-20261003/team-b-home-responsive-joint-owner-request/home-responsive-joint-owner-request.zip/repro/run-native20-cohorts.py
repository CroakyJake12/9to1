#!/usr/bin/env python3
"""Root-gated actual native probe; import/syntax check never starts SDK."""
import argparse, datetime, hashlib, json, os, pathlib, signal, subprocess, time
BASE=pathlib.Path(__file__).resolve().parent
MANIFEST=BASE/'authored-native20-source-freeze-v2.json'
EXPECTED='4d7c009cba662525ba93a048aa76b36bca911f6e27aec2c49772cbb715f65e9a'
REPO=pathlib.Path('/workspace/team-b-astra-browser-validation')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(out,name,data):
 target=out/name; temporary=target.with_name(target.name+'.writing')
 temporary.write_text(json.dumps(data,indent=2)+'\n'); temporary.replace(target)
def snapshot():
 rows=[]
 for directory,dirs,files in os.walk(REPO):
  dirs[:]=[d for d in dirs if d not in {'.git','bin','obj','node_modules','staticwebassets'}]
  for name in sorted(files):
   p=pathlib.Path(directory)/name
   if p.suffix.lower() in {'.cs','.csproj','.props','.targets','.cui','.axaml','.ttf'}:
    rows.append({'path':str(p.relative_to(REPO)),'bytes':p.stat().st_size,'sha256':digest(p)})
 return sorted(rows,key=lambda r:r['path'])
def selected_requirements(m):
 rows=[{'path':str(MANIFEST),'sha256':EXPECTED},*m['sourcePins']]
 rows.extend(m[k] for k in ['predecessor','preservedOriginalFixture','repairPatch','independentReviewRequest'])
 rows.extend([{'path':m['proposal']['path'],'sha256':m['proposal']['intrinsicWrapSha256']},
              {'path':str(BASE/'Home.base-one-wrap.cui'),'sha256':m['proposal']['baseSha256']}])
 return rows
def inspect_selected(rows):
 results=[]
 for row in rows:
  p=pathlib.Path(row['path']); r={'path':str(p),'expectedSHA256':row['sha256']}
  try: r.update({'actualSHA256':digest(p),'bytes':p.stat().st_size});r['matches']=r['actualSHA256']==r['expectedSHA256']
  except OSError as error: r.update({'matches':False,'error':repr(error)})
  results.append(r)
 return results
def terminate_owned_group(proc):
 # start_new_session gives this process its own group, never the root SDK lane.
 try: os.killpg(proc.pid,signal.SIGTERM)
 except ProcessLookupError: pass
 try: proc.wait(timeout=5)
 except subprocess.TimeoutExpired: pass
 # Also terminate owned descendants even if the group leader already exited.
 try: os.killpg(proc.pid,signal.SIGKILL)
 except ProcessLookupError: pass
 proc.wait(timeout=5)
def run_owned(name,command,data,out,env,cwd,deadline):
 data.mkdir();local=env.copy();local['HAVEN_DATA_DIR']=str(data)
 record={'name':name,'command':command,'deadlineSeconds':deadline,'dataRoot':str(data),'status':'STARTING'}
 write(out,name+'-process.json',record)
 start=time.monotonic();proc=None
 try:
  with (out/(name+'.log')).open('wb') as log:
   proc=subprocess.Popen(command,cwd=cwd,env=local,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   record.update({'status':'RUNNING','pid':proc.pid,'ownedProcessGroup':proc.pid});write(out,name+'-process.json',record)
   try: record.update({'exit':proc.wait(timeout=deadline),'status':'EXITED'})
   except subprocess.TimeoutExpired: record.update({'exit':None,'status':'DEADLINE_EXCEEDED'})
 except BaseException as error:
  record.update({'exit':None,'status':'PROCESS_ERROR','error':repr(error)});raise
 finally:
  if proc is not None:
   try: terminate_owned_group(proc);record['ownedGroupCleanup']='TERMINATE_AND_KILL_SENT_PROCESS_REAPED'
   except BaseException as error: record['cleanupError']=repr(error)
  record['seconds']=time.monotonic()-start
  if (out/(name+'.log')).exists():record['logSHA256']=digest(out/(name+'.log'))
  write(out,name+'-process.json',record)
 return record
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
 parser.add_argument('--build-deadline',type=float,default=1800);parser.add_argument('--cohort-deadline',type=float,default=180)
 args=parser.parse_args();out=pathlib.Path(args.output)
 if not out.is_absolute() or out.exists():raise SystemExit('Pass a fresh absolute output directory.')
 if not 0<args.build_deadline<=3600 or not 0<args.cohort_deadline<=600:raise SystemExit('Positive owned process deadlines required: build<=3600s, cohort<=600s.')
 if digest(MANIFEST)!=EXPECTED:raise SystemExit('Frozen manifest changed.')
 m=json.loads(MANIFEST.read_text());selected=selected_requirements(m)
 selected.append({'path':str(pathlib.Path(__file__).resolve()),'sha256':digest(pathlib.Path(__file__).resolve())})
 out.mkdir();records=[];before=None;after=None;before_selected=None;after_selected=None;failure=None;final_ok=False
 def interrupted(signum,frame):raise InterruptedError('Runner interrupted by signal '+str(signum))
 previous={s:signal.signal(s,interrupted) for s in [signal.SIGTERM,signal.SIGINT]}
 env=os.environ.copy();env.update({'DOTNET_CLI_HOME':'/workspace/team-b-tooling/dotnet-home','NUGET_PACKAGES':'/workspace/team-b-tooling/nuget','XDG_CACHE_HOME':str(BASE.parent/'font-cache')})
 try:
  before_selected=inspect_selected(selected);write(out,'selected-inputs-before.json',before_selected)
  if not all(r['matches'] for r in before_selected):raise RuntimeError('Frozen selected input mismatch before SDK.')
  before=snapshot();write(out,'source-before.json',before)
  # Disable SDK servers in this bounded runner without changing the compiled sources.
  build_command=[*m['oneBuildPreflight'],'--disable-build-servers','-nodeReuse:false']
  build=run_owned('build',build_command,out/'build-data',out,env,REPO,args.build_deadline);records.append(build);write(out,'commands-results.json',records)
  if build['exit']==0 and 'cleanupError' not in build:
   for cohort in m['cohorts']:
    command=cohort['command'].copy();report=out/(cohort['name']+'.json');command[3]=str(report)
    result=run_owned(cohort['name'],command,out/(cohort['name']+'-data'),out,env,REPO,args.cohort_deadline);records.append(result)
    if report.exists():
     r=json.loads(report.read_text());result.update({'reportSHA256':digest(report),'executedChecks':len(r['checks']),'passed':sum(c['passed'] for c in r['checks']),'failed':sum(not c['passed'] for c in r['checks']),'diagnosticPropertyMutation':r['diagnosticPropertyMutation']})
    else:result.update({'executedChecks':0,'caseCounts':'NOT_AVAILABLE_NATIVE_SETUP_OR_EXECUTION_FAILURE'})
    write(out,'commands-results.json',records)
 except BaseException as error:failure=repr(error)
 finally:
  try:after=snapshot();write(out,'source-after.json',after)
  except BaseException as error:failure=(failure or '')+'; source-final-error='+repr(error)
  try:after_selected=inspect_selected(selected);write(out,'selected-inputs-after.json',after_selected)
  except BaseException as error:failure=(failure or '')+'; selected-final-error='+repr(error)
  custody_ok=before_selected is not None and after_selected is not None and all(r['matches'] for r in after_selected) and before_selected==after_selected
  final_ok=failure is None and before is not None and before==after and custody_ok and len(records)==8 and all(r['exit']==0 and 'cleanupError' not in r for r in records)
  write(out,'final.json',{'recordedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifestSHA256':EXPECTED,'selectedSourceInputsBefore':len(before or []),'selectedSourceInputsAfter':len(after or []),'selectedSourceInputsUnchanged':before is not None and before==after,'selectedExplicitInputsUnchangedAndPinned':custody_ok,'records':records,'notRunCohorts':len(m['cohorts'])-sum(r['name']!='build' for r in records),'runnerError':failure,'firstFailure':next((r for r in records if r['exit']!=0 or 'cleanupError' in r),None),'exit':0 if final_ok else 1,'limits':'Native source-linked geometry only; disabled horizontal property cohorts diagnostic. No browser/ink/readability/fullHome acceptance. Abrupt OS SIGKILL/power loss cannot guarantee finally; per-process durable records preserve last known state.'})
  for s,h in previous.items():signal.signal(s,h)
 return 0 if final_ok else 1
if __name__=='__main__':raise SystemExit(main())
