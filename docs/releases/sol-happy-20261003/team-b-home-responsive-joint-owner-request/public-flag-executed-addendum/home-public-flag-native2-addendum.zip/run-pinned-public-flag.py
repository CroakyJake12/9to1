#!/usr/bin/env python3
"""Root-gated bounded actual-DLL native cohort; authoring/import does not start SDK."""
import argparse,datetime,hashlib,importlib.util,json,os,pathlib,signal
p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=pathlib.Path(a.output)
if not out.is_absolute() or out.exists():raise SystemExit('Fresh absolute evidence output required.')
base=pathlib.Path(__file__).resolve().parent;manifest=base/'manifest.json';expected='adbb61e5e40d2ac13a58bdabf62031a30d51d03d6be9cd28e19a4cc71b2c16bf'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if digest(manifest)!=expected:raise SystemExit('Exact native DLL cohort manifest mismatch.')
m=json.loads(manifest.read_text());helper=base.parent/'run-native20-cohorts.py'
if digest(helper)!='11964712f31865135025ba918a48db29671e1139245515425bb21b9152f4f349':raise SystemExit('Exact bounded process helper changed.')
s=importlib.util.spec_from_file_location('native20',helper);r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
selected=[m['project'],m['managedDependenciesSourceReceipt'],m['markupPin'],m['sameAssertionOriginal'],m['originalPortable72UnrunSourcePackage'],*m['sourcePins'],*m['managedPins'],*m['nativeLinuxX64Pins'],*m['referenceRelatedPins'],m['referenceRelatedSDKContract'],*m['actualFontSourcePins'],{'path':str(manifest),'sha256':expected},{'path':str(helper),'sha256':digest(helper)},{'path':str(pathlib.Path(__file__).resolve()),'sha256':digest(pathlib.Path(__file__).resolve())}]
out.mkdir();before=None;after=None;records=[];failure=None;final_ok=False
previous={}
def interrupted(signum,frame):raise InterruptedError('Runner interrupted '+str(signum))
for sig in [signal.SIGINT,signal.SIGTERM]:previous[sig]=signal.signal(sig,interrupted)
env=os.environ.copy();env.update({'DOTNET_CLI_HOME':'/workspace/team-b-tooling/dotnet-home','NUGET_PACKAGES':'/workspace/team-b-tooling/nuget','XDG_CACHE_HOME':str(base.parent.parent/'font-cache')})
try:
 before=r.inspect_selected(selected);r.write(out,'inputs-before.json',before)
 if not all(x['matches'] for x in before):raise RuntimeError('Actual pinned source/DLL/native/font input changed beforeSDK.')
 build=r.run_owned('build',m['plannedBuild'],out/'build-data',out,env,base,1800);records.append(build);r.write(out,'commands-results.json',records)
 if build['exit']==0 and 'cleanupError' not in build:
  for cohort in m['plannedNativeCohorts']:
   command=cohort['command'].copy();report=out/(cohort['name']+'.json');command[3]=str(report)
   result=r.run_owned(cohort['name'],command,out/(cohort['name']+'-data'),out,env,base,180);records.append(result)
   if report.exists():
    q=json.loads(report.read_text());result.update({'executedChecks':len(q['checks']),'passed':sum(x['passed'] for x in q['checks']),'failed':sum(not x['passed'] for x in q['checks']),'reportSHA256':digest(report),'diagnosticPropertyMutation':q['diagnosticPropertyMutation'],'declaredSurfaceConstraint':q['declaredSurfaceConstraint']})
   else:result.update({'executedChecks':0,'caseCounts':'NOT_AVAILABLE_NATIVE_SETUP_FAILURE'})
   r.write(out,'commands-results.json',records)
except BaseException as e:failure=repr(e)
finally:
 try:after=r.inspect_selected(selected);r.write(out,'inputs-after.json',after)
 except BaseException as e:failure=(failure or '')+'; input-final-error='+repr(e)
 custody=before is not None and after is not None and before==after and all(x['matches'] for x in after)
 final_ok=failure is None and custody and len(records)==3 and all(x['exit']==0 and 'cleanupError' not in x for x in records) and all(x.get('executedChecks')==20 and x.get('declaredSurfaceConstraint') is True and x.get('diagnosticPropertyMutation') is False for x in records[1:])
 r.write(out,'final.json',{'recordedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifestSHA256':expected,'pinnedInputsUnchanged':custody,'inputCount':len(selected),'records':records,'runnerError':failure,'firstFailure':next((x for x in records if x['exit']!=0 or 'cleanupError' in x),None),'notRunCohorts':2-sum(x['name']!='build' for x in records),'exit':0 if final_ok else 1,'limits':'Actual maintained DLL/source consumption native geometry only; originalfullgraph72package remains separate unrunproposal source. No SDKgraph/vendor rebuild, no browser/AT/readability/domain/installed acceptance. SIGKILL/power loss may prevent finally; durable ownprocessrecords retain last state.'})
 for sig,handler in previous.items():signal.signal(sig,handler)
raise SystemExit(0 if final_ok else 1)
