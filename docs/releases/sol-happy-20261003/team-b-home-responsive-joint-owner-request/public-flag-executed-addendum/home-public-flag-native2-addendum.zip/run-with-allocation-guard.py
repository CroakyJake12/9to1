#!/usr/bin/env python3
"""Evidence-only allocation supervisor; starts only the root-granted frozen cohort."""
import datetime,hashlib,json,os,pathlib,signal,subprocess,sys,time
base=pathlib.Path(__file__).resolve().parent
runner=base/'run-pinned-public-flag.py'
if hashlib.sha256(runner.read_bytes()).hexdigest()!='cfa7afc898b4454e8cad9a30770e799d4fd08049fe19a3b09b9e8ead6055ffef':raise SystemExit('Exact approved runner changed.')
out=base/'allocation-run01'
if out.exists():raise SystemExit('Allocation-run01 exists; preserve original evidence.')
out.mkdir();temp=out/'workspace-tmp';temp.mkdir()
CAP=64*1024*1024;FLOOR=256*1024*1024
def allocated():
 total=0
 for directory,dirs,files in os.walk(base):
  for name in files:
   try:total+=(pathlib.Path(directory)/name).stat().st_blocks*512
   except FileNotFoundError:pass
 return total
def freebytes():s=os.statvfs('/workspace');return s.f_bavail*s.f_frsize
def write(name,data):
 p=out/name;t=p.with_name(p.name+'.writing');t.write_text(json.dumps(data,indent=2)+'\n');t.replace(p)
initial=allocated();initialfree=freebytes()
if initialfree<FLOOR+CAP:raise SystemExit('Insufficient initial workspace headroom for hard output budget.')
env=os.environ.copy();env['TMPDIR']=str(temp)
command=[sys.executable,str(runner),'--output',str(out/'cohort')]
proc=None;peak=initial;minimum=initialfree;breach=None;status=[]
try:
 with (out/'runner-stdout.log').open('wb') as log:
  proc=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   current=allocated();remaining=freebytes();peak=max(peak,current);minimum=min(minimum,remaining)
   if current>CAP or remaining<FLOOR:
    breach={'allocatedBytes':current,'workspaceFreeBytes':remaining,'kind':'CAP' if current>CAP else 'HEADROOM','timeUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    # SIGTERM reaches frozen runner's own interruption/finally/group-cleanup path.
    proc.send_signal(signal.SIGTERM)
    try:proc.wait(timeout=20)
    except subprocess.TimeoutExpired:
     # Only the exact durable process groups issued inside this cohort are candidates.
     for record in (out/'cohort').glob('*-process.json'):
      data=json.loads(record.read_text());group=data.get('ownedProcessGroup')
      if group and data.get('status')=='RUNNING':
       try:os.killpg(group,signal.SIGKILL);status.append({'forcedOwnGroup':group})
       except ProcessLookupError:pass
     proc.kill();proc.wait(timeout=5)
    break
   time.sleep(0.25)
  proc.wait()
finally:
 if proc is not None and proc.poll() is None:
  proc.send_signal(signal.SIGTERM)
  try:proc.wait(timeout=20)
  except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5);status.append({'runnerForcedKill':True})
 peak=max(peak,allocated());minimum=min(minimum,freebytes())
 write('allocation.json',{'recordedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'TMPDIR':str(temp),'capBytes':CAP,'workspaceHeadroomFloorBytes':FLOOR,'initialAllocatedBytes':initial,'peakAllocatedBytes':peak,'finalAllocatedBytes':allocated(),'initialWorkspaceFreeBytes':initialfree,'minimumWorkspaceFreeBytes':minimum,'finalWorkspaceFreeBytes':freebytes(),'breach':breach,'supervisorCleanup':status,'runnerExit':proc.returncode if proc else None,'scope':'Own new fixture dir allocated st_blocks bytes, including actual copiedDLL/native/PDB/XML/bin/obj/log/tmp. Existing referenced productioninput directories untouched. No SDK/browser/AT result inferred from budget proof.'})
raise SystemExit(proc.returncode if proc and breach is None and peak<=CAP and minimum>=FLOOR else 1)
