Selected public CUI lifetime source and observed native evidence only.

Frozen C2 source fe64ee093177fe359efabf69bd748e967f99caa6 is the exact existing delivered optional typed port + consumer, conserving approved TextChanging. Root composition a761e76b/push a9dc1a80 is separate. Owner adoption/full acceptance remain open.

Actual Debug and Release: unchanged original3 PASS3, owning Runtime.Tests PASS90, BrowserAccounts PASS15, AccountFactory PASS6, corrected preservation PASS5, all0 skips/exit0. C6 independently executed actual Release3+5 once each with complete source/catalog readback. C6 did not independently capture the before5 catalog; C2 full provenance is retained.

Original source-bound runtime04 replay is meaningfully red:3 executed,2 PASS,1 FAIL,0 skips/exit1; it retains original self-cancellation. Initial new generic preservation fixture is4 PASS/1 FAIL before Button dispatch in both configurations; the actual declared-action fixture correction and unchanged assertions/source are retained separately.

Public source-before/after catalogs and compiled Release body catalogs are included. Actual immutable Release DLL families129/129/208 files remain preserved locally and are not duplicated here. Retirement inventory covers only completed task-owned Debug caches; source/raw TRX/logs/fixtures/indices/packages/actual Release runtimes are preserved.

No private fixture DB/manifest/credentials, TLS key, browser profiles, npm/NuGet cache or installed package tree is included. No provider launch/mutation, real browser PKCE, strict .NET RSA/auth_revision, BFCache, token expiry, hosted/native/global acceptance is inferred. New current-public-API local browser PKCE proposal is a separate source artifact with actual seven-case execution NOT_RUN.
