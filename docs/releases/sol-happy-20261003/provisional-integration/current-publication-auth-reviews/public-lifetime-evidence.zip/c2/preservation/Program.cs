using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Interactivity;
using Avalonia.LogicalTree;
using CakeOS.Cui;
using CakeOS.Cui.Language;
using CakeOS.Cui.Runtime;
using NineToOne.Web.Accounts;
using NineToOne.Web.Services;

// Source-built candidate preservation only; no issuer/provider or native/browser authority.
var cases = new (string, Func<CancellationToken, Task>)[] {
    ("already cancelled view cannot initiate selected sign-in", async deadline => {
        using var viewCancellation = new CancellationTokenSource(); viewCancellation.Cancel(); var calls = 0;
        await using var view = new AccountBrowserBindings(new Transport(), a => { a(); return Task.CompletedTask; }, _ => { calls++; return Task.CompletedTask; });
        await Cancelled(view.DispatchWithLifetimeAsync("RequestSignIn", null, new(viewCancellation.Token, default)).AsTask(), deadline);
        Check(calls == 0 && !view.HasOutstandingBrokerWork, "CANCELLED_VIEW_ADMITTED");
    }),
    ("already cancelled caller cannot initiate selected sign-in", async deadline => {
        using var caller = new CancellationTokenSource(); caller.Cancel(); var calls = 0;
        await using var view = new AccountBrowserBindings(new Transport(), a => { a(); return Task.CompletedTask; }, _ => { calls++; return Task.CompletedTask; });
        await Cancelled(view.DispatchWithLifetimeAsync("RequestSignIn", null, new(default, caller.Token)).AsTask(), deadline);
        Check(calls == 0 && !view.HasOutstandingBrokerWork, "CANCELLED_CALLER_ADMITTED");
    }),
    ("actual native view retirement during held admission has zero broker effects and true drain", async deadline => {
        await using var session = HeadlessUnitTestSession.StartNew(typeof(PreservationApplication));
        await session.Dispatch(async () => {
            using var loader = new CuiControlLoader(); var entered = Signal(); var release = Signal(); var calls = 0;
            var view = new AccountBrowserBindings(new Transport(), async action => { entered.TrySetResult(); await release.Task; action(); }, _ => { calls++; return Task.CompletedTask; });
            Task? actual = null; Task? drain = null;
            try {
                var button = await AccountButton(loader, view, deadline);
                button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); actual = loader.WhenActionsIdleAsync();
                await entered.Task.WaitAsync(deadline); view.RevokePrivateContext(); loader.Dispose(); drain = view.DisposeAsync().AsTask();
                Check(calls == 0 && !actual.IsCompleted && !drain.IsCompleted, "HELD_ADMISSION_EFFECT_OR_FALSE_DRAIN");
                release.TrySetResult(); await actual.WaitAsync(deadline); await drain.WaitAsync(deadline);
                Check(calls == 0 && !view.HasOutstandingBrokerWork, "RETIRED_ADMISSION_DISPATCHED");
            } finally { release.TrySetResult(); loader.Dispose(); if (actual is not null) await actual.WaitAsync(deadline); await view.DisposeAsync().AsTask().WaitAsync(deadline); }
            return true;
        }, deadline);
    }),
    ("typed handoff retains real caller cancellation after retiring only the view", async deadline => {
        using var caller = new CancellationTokenSource(); using var retiredView = new CancellationTokenSource(); var entered = Signal(); var observed = false;
        var view = new AccountBrowserBindings(new Transport(), a => { a(); return Task.CompletedTask; }, async token => {
            entered.TrySetResult(); try { await Task.Delay(Timeout.InfiniteTimeSpan, token); }
            catch (OperationCanceledException) { observed = token.IsCancellationRequested; throw; }
        });
        Task? actual = null;
        try {
            actual = view.DispatchWithLifetimeAsync("RequestSignIn", null, new(retiredView.Token, caller.Token)).AsTask();
            await entered.Task.WaitAsync(deadline); retiredView.Cancel(); view.RevokePrivateContext();
            Check(!actual.IsCompleted && !observed && view.HasOutstandingBrokerWork, "HANDOFF_LOST_SELECTED_WORK");
            caller.Cancel(); await actual.WaitAsync(deadline);
            Check(observed && !view.HasOutstandingBrokerWork, "REAL_CALLER_LOST_AFTER_HANDOFF");
        } finally { caller.Cancel(); if (actual is not null) await actual.WaitAsync(deadline); await view.DisposeAsync().AsTask().WaitAsync(deadline); }
    }),
    ("actual generic native dispatcher retains view cancellation and waits its real ignored reply", async deadline => {
        await using var session = HeadlessUnitTestSession.StartNew(typeof(PreservationApplication));
        await session.Dispatch(async () => {
            using var loader = new CuiControlLoader(); var generic = new GenericDispatcher(); loader.SetActionDispatcher(generic);
            var root = loader.Load(new CuiRichParser().Parse("<Cui><Actions><Action name=\"Hold\" command=\"test.hold\" /></Actions><Page><Button action=\"Hold\">Hold</Button></Page></Cui>", "generic.cui")) ?? throw new InvalidOperationException("GENERIC_NATIVE_LOAD_FAILED");
            loader.WireBindings(root); var button = root.GetLogicalDescendants().OfType<Button>().Single();
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); var actual = loader.WhenActionsIdleAsync();
            try {
                await generic.Entered.Task.WaitAsync(deadline); loader.Dispose();
                Check(generic.Cancelled && !actual.IsCompleted, "DEFAULT_GENERIC_LIFETIME_OR_TASK_CHANGED");
                generic.Release.TrySetResult(); await actual.WaitAsync(deadline);
                button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); await loader.WhenActionsIdleAsync().WaitAsync(deadline);
                Check(generic.Calls == 1, "GENERIC_RETIRED_BUTTON_REDISPATCHED");
            } finally { generic.Release.TrySetResult(); loader.Dispose(); await actual.WaitAsync(deadline); }
            return true;
        }, deadline);
    }),
};
var pass = 0; var fail = 0;
foreach (var (name, run) in cases) {
    using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(15));
    try { await run(deadline.Token); pass++; Console.WriteLine($"PASS {name}"); }
    catch (Exception error) { fail++; Console.WriteLine($"FAIL {name} Type={error.GetType().Name} Code={error.Message}"); }
}
Console.WriteLine($"Discovered={cases.Length} Executed={pass + fail} Passed={pass} Failed={fail} Skipped=0 Scope=NATIVE_UNIT_EXISTING_PROPOSAL_PRESERVATION_NO_PROVIDER_AUTHORITY");
return fail == 0 ? 0 : 1;

static void Check(bool value, string reason) { if (!value) throw new InvalidOperationException(reason); }
static TaskCompletionSource Signal() => new(TaskCreationOptions.RunContinuationsAsynchronously);
static async Task Cancelled(Task task, CancellationToken deadline) { try { await task.WaitAsync(deadline); throw new InvalidOperationException("CANCELLED_REQUEST_COMPLETED"); } catch (OperationCanceledException) when (!deadline.IsCancellationRequested) { } }
static async Task<Button> AccountButton(CuiControlLoader loader, AccountBrowserBindings view, CancellationToken token) {
    var text = await File.ReadAllTextAsync(Path.Combine(AppContext.BaseDirectory, "Accounts.cui"), token);
    loader.SetBindingContext(view); loader.SetActionDispatcher(view);
    var root = loader.Load(new CuiRichParser().Parse(text, "Accounts.cui")) ?? throw new InvalidOperationException("ACCOUNT_NATIVE_LOAD_FAILED");
    loader.WireBindings(root); return root.GetLogicalDescendants().OfType<Button>().Single(button => button.Name == "account-signin");
}
public sealed class PreservationApplication : Application { }
public sealed class Transport : IAccountBrowserTransport {
    public Task<JsonElement> InvokeAsync(string action, JsonElement? arguments, CancellationToken token) {
        using var body = JsonDocument.Parse("{\"ok\":false,\"error\":{\"code\":\"AuthenticationRequired\"}}"); return Task.FromResult(body.RootElement.Clone());
    }
}
public sealed class GenericDispatcher : ICuiActionDispatcher {
    public readonly TaskCompletionSource Entered = new(TaskCreationOptions.RunContinuationsAsynchronously);
    public readonly TaskCompletionSource Release = new(TaskCreationOptions.RunContinuationsAsynchronously);
    public int Calls; public bool Cancelled;
    public async ValueTask DispatchAsync(string command, object? parameter, CancellationToken cancellationToken = default) {
        Calls++; using var cancel = cancellationToken.Register(() => Cancelled = true); Entered.TrySetResult(); await Release.Task;
    }
}
