#!/usr/bin/env python3
import argparse, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--dotnet', default=shutil.which('dotnet'))
parser.add_argument('--log', required=True)
args=parser.parse_args()
if not args.dotnet: raise SystemExit('An installed .NET10 runtime is required; no installation is performed.')
base=Path(__file__).resolve().parent
manifest=json.loads((base/'RUNTIME-MANIFEST.json').read_text())
def verify():
 for row in manifest['runtimeFiles']:
  path=base/row['relativePath']
  if not path.is_file() or path.stat().st_size!=row['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
   raise RuntimeError('Original runtime pin mismatch')
verify()
log=Path(args.log).resolve()
if log.exists(): raise SystemExit('Use a fresh log path to preserve prior results.')
with log.open('xb') as stream:
 try:
  process=subprocess.run([args.dotnet,str(base/'runtime/ActualCallerProbe.dll')],cwd=base/'runtime',stdout=stream,stderr=subprocess.STDOUT,timeout=120,check=False)
 except subprocess.TimeoutExpired:
  print('SETUP_OR_RUNTIME_DEADLINE_FAIL; prior output retained')
  raise SystemExit(124)
verify()
text=log.read_text()
receipt=re.search(r'Discovered=(\d+) Executed=(\d+) Passed=(\d+) Failed=(\d+) Skipped=(\d+)',text)
expected=receipt and tuple(map(int,receipt.groups()))==(3,3,2,1,0) and 'ResetReceipt CallbackCalls=1 CallerCancelled=True AfterResetContinuation=0 PrivateEmpty=True' in text and process.returncode==1
print(json.dumps({'exitCode':process.returncode,'expectedOriginalMeaningfulRedObtained':bool(expected),'counts':dict(zip(['discovered','executed','passed','failed','skipped'],map(int,receipt.groups()))) if receipt else None,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),'scope':'NATIVE_UNIT_ACTUAL_CANONICAL_LOADER_BUTTON_NOT_PROVIDER_BROWSER_AUTHORITY'}))
# Keep the original meaningful red exit1; reproducing a defect does not turn it into acceptance PASS.
sys.exit(process.returncode)
