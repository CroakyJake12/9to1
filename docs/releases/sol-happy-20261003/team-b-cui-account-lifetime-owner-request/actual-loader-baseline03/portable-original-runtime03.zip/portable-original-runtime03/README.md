The runtime folder contains the exact 33 original managed dependencies and 2 Linux-x64 native libraries pinned by baseline03, plus the exact executed probe DLL/deps/runtimeconfig/apphost and canonical Accounts.cui. No NuGet/HTTP/CLI cache, private credential, proposed owner port, or account-consumer candidate is included. The paired source packet and producer build provenance remain separate.

With an existing .NET10 runtime on Linux x64, from any extracted directory run:

    python3 run-original.py --dotnet /path/to/dotnet --log /fresh/path/original-baseline.log

This invokes the original compiled DLL only, verifies all 40 runtime files before and after, imposes a 120-second process deadline, and preserves exit 1. Expected unchanged controls: 3 executed, 2 PASS, 1 meaningful FAIL, no skips; the actual sign-in Button caller is cancelled by its own view reset, continuation count remains zero, private fields are already cleared. Refresh ignored-reply drain and true external caller cancellation pass. Inspect counts/log; setup failures are not the expected meaningful red. The wrapper is authored packaging code (not independently executed here); original runtime was actually executed and pinned in the paired baseline receipt.

Native Avalonia headless Button dispatch with scripted callbacks/transport only. This does not establish physical browser, issuer/OAuth, actor grants, native interop terminal closure, or proposed owner-port correctness. The first oracle must be rerun against a separately source-owned candidate after exact maintained A1 delivery; the original remains untouched.
