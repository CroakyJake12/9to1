#!/usr/bin/env python3
import argparse, hashlib, json, re, shutil, subprocess, sys
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--dotnet', default=shutil.which('dotnet'))
parser.add_argument('--log', required=True)
args=parser.parse_args()
if not args.dotnet: raise SystemExit('An installed .NET10 runtime is required; no installation is performed.')
base=Path(__file__).resolve().parent
manifest=json.loads((base/'RUNTIME-MANIFEST.json').read_text())
def verify():
 for row in manifest['runtimeFiles']:
  path=base/row['relativePath']
  if not path.is_file() or path.stat().st_size!=row['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
   raise RuntimeError('Original runtime pin mismatch')
verify()
log=Path(args.log).resolve()
if log.exists(): raise SystemExit('Use a fresh log path to preserve prior results.')
exit_code=None
setup_failed=False
timed_out=False
post_integrity_failed=False
try:
 with log.open('xb') as stream:
  try:
   process=subprocess.run([args.dotnet,str(base/'runtime/ActualCallerProbe.dll')],cwd=base/'runtime',stdout=stream,stderr=subprocess.STDOUT,timeout=120,check=False)
   exit_code=process.returncode
  except subprocess.TimeoutExpired:
   timed_out=True
  except OSError:
   setup_failed=True
finally:
 # Always check exact runtime custody after execution/setup failure/deadline.
 # subprocess.run timeout terminates and waits its own direct child first.
 try: verify()
 except (OSError, RuntimeError): post_integrity_failed=True
text=log.read_text() if log.exists() else ''
receipt=re.search(r'Discovered=(\d+) Executed=(\d+) Passed=(\d+) Failed=(\d+) Skipped=(\d+)',text)
expected=bool(receipt and tuple(map(int,receipt.groups()))==(3,3,2,1,0) and 'ResetReceipt CallbackCalls=1 CallerCancelled=True AfterResetContinuation=0 PrivateEmpty=True' in text and exit_code==1 and not timed_out and not setup_failed and not post_integrity_failed)
# Original reproduced defect remains exit1; altered/missing evidence cannot exit0.
wrapper_exit=124 if timed_out else 2 if not expected else 1
print(json.dumps({'exitCode':exit_code,'wrapperExitCode':wrapper_exit,'expectedOriginalMeaningfulRedObtained':expected,'deadlineFailure':timed_out,'setupFailure':setup_failed,'postRuntimeIntegrityFailure':post_integrity_failed,'counts':dict(zip(['discovered','executed','passed','failed','skipped'],map(int,receipt.groups()))) if receipt else None,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest() if log.exists() else None,'scope':'NATIVE_UNIT_ACTUAL_CANONICAL_LOADER_BUTTON_NOT_PROVIDER_BROWSER_AUTHORITY'}))
sys.exit(wrapper_exit)
