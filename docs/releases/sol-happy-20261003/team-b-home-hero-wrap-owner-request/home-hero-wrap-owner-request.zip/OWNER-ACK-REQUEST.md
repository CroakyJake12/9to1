# Exact Home hero-wrap owner ACK request

Please ACK only the attached one-property change, `text-wrapping="Wrap"`, on the existing hero explanatory TextBlock. Exact unchanged owner source SHA00589e2603a73dd6016cb9d8fc47d17cf2292aab354fbf3079d5767bb9533571 → proposed SHA9247bee96e0b7a6caba1ec74f3cc3ae99420dfec2deaea2d7828a459fbfb33fd. No shared source was edited. Removing exactly the added attribute reconstructs the complete original bytes.

Actual production BrowserApplication.Render SHA80826b95eecbfcb047654cf5dd3aa3033e9aaef7bc89080f93a4db90d7d3971e and actual owner CUI/fonts/native controls were used. Build succeeded with zero warnings/errors. All four cohorts executed the SAME12 assertions: canonical1440 and canonical360 each10PASS2FAIL; canonical1440 with diagnostic outerHorizontalScrollBarVisibility.Disabled also10PASS2FAIL; exactoneWrapproposal1440 12PASS/exit0. Each canonicalfailure process exitedSIGABRT(-6) only after logging all12 and throwing the explicit assertion-failure exception.

The unchanged 420px native hero copy has a439.6875px complete text range, overflowing assigned width and intersecting the observed-status column. Wrapping produces two lines and removes these measured collisions. Changing only the outerbrowser scroll does not repair them. Narrowcanonical native root remains1031px while viewport360px; this request does not repair or accept responsiveHome.

All7,789 captured source/font inputs are identical before/after. The request includes whole original/proposed CUI, exactpatch, actualhost/control/layout source witnesses, identical probe/project, fullnativeglyph JSON and logs, native DLL/source closure hashes and testDLL, font-source pins, complete selected live8534 paragraphs and B2 source review. Native CaptureRenderedFrame ran, but noPNG was exported; no screenshot/visual/ink/AT/browser assertion is claimed here.

This is a bounded native range/layout repair proposal. It does not establish completeHome, browseraccessibility, generalreadability, mobile/reflow or fullproductparity. Apply only through owner ACK and rerun actual canonical/source+freshbrowser journey after application.
