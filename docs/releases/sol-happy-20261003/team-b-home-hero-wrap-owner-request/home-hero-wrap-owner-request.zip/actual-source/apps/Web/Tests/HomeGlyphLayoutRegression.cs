using System.Reflection;
using System.Text.Json;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Headless;
using Avalonia.VisualTree;
using CakeOS.Cui.Language;
using CakeOS.Cui.Runtime;
using NineToOne.Web;

// Actual production Render/owner Home projection/native glyph layout only.
// No browser/runtime/rendered readability acceptance; optional disabled scroll
// is an explicitly diagnostic native property change, never shipped acceptance.
if (args.Length != 5) throw new ArgumentException("Home.cui output.json width height production|disable-horizontal-diagnostic");
var sourcePath = Path.GetFullPath(args[0]);
var outputPath = Path.GetFullPath(args[1]);
var width = double.Parse(args[2], System.Globalization.CultureInfo.InvariantCulture);
var height = double.Parse(args[3], System.Globalization.CultureInfo.InvariantCulture);
var diagnostic = args[4] == "disable-horizontal-diagnostic";
if (args[4] != "production" && !diagnostic) throw new ArgumentException("Unknown diagnostic mode.");
if (!double.IsFinite(width) || !double.IsFinite(height) || width <= 0 || height <= 0) throw new ArgumentException("Finite positive dimensions required.");
await using var session = HeadlessUnitTestSession.StartNew(typeof(HomeGlyphApplication));
var failures = await session.Dispatch(() =>
{
    var parser = new CuiRichParser();
    var document = parser.Parse(File.ReadAllText(sourcePath), sourcePath);
    if (parser.Diagnostics.Diagnostics.Any(d => d.Severity == CuiDiagnosticSeverity.Error)) throw new InvalidDataException("Canonical Home parse failed.");
    var bindings = new BrowserHomeContext(document, _ => throw new InvalidOperationException("This glyph probe does not navigate or invent service actions."));
    if (!bindings.Open(new("home.dashboard"))) throw new InvalidOperationException("Actual unavailable Home context did not open dashboard.");
    var app = new BrowserApplication();
    var view = (ContentControl)typeof(BrowserApplication).GetField("_view", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(app)!;
    var render = typeof(BrowserApplication).GetMethod("Render", BindingFlags.NonPublic | BindingFlags.Instance)!;
    var window = new Window { Content = view, Width = width, Height = height };
    window.Show();
    try
    {
        if (render.Invoke(app, [new BrowserCuiSurface(document, bindings, bindings), "#/home.dashboard"]) is not true)
            throw new InvalidOperationException("Actual BrowserApplication.Render failed.");
        var scroll = (ScrollViewer)view.Content!;
        if (diagnostic) scroll.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        using var frame = window.CaptureRenderedFrame();
        if (frame is null) throw new InvalidOperationException("Actual native rendered frame unavailable.");
        var root = (Control)scroll.Content!;
        var controls = root.GetVisualDescendants().OfType<Control>().Prepend(root).ToArray();
        Control Named(string name) => controls.Single(c => c.Name == name);
        Rect InRoot(Control control)
        {
            var origin = control.TranslatePoint(default, root) ?? throw new InvalidOperationException("Detached actual native control.");
            return new Rect(origin, control.Bounds.Size);
        }
        var checks = new List<object>();
        var failed = 0;
        void Check(string name, bool passed)
        { checks.Add(new { name, passed }); Console.WriteLine($"{(passed ? "PASS" : "FAIL")}: {name}"); if (!passed) ++failed; }
        var order = new[] { "welcome-heading", "welcome-copy", "dashboard-brief", "home-hero", "operation-status", "navigation-status", "app-shortcuts", "upcoming-events", "dashboard-layout-controls" };
        var sections = order.Select(id => new { id, bounds = InRoot(Named(id)) }).ToArray();
        // Preserve the same original eight section-order assertions.
        foreach (var pair in sections.Zip(sections.Skip(1)))
            Check($"{pair.Second.id} follows {pair.First.id}", pair.Second.bounds.Y + 0.01 >= pair.First.bounds.Bottom);
        const string explanation = "Open a Space, manage your apps, or review what needs attention.";
        var copy = controls.OfType<TextBlock>().Single(text => text.Text == explanation);
        var column = InRoot(Named("observed-status"));
        var bounds = InRoot(copy);
        var layout = copy.TextLayout;
        var glyphs = layout.HitTestTextRange(0, explanation.Length).ToArray();
        if (glyphs.Length == 0) throw new InvalidOperationException("Actual full text glyph range unavailable.");
        var fullRange = layout.TextLines.Sum(line => line.Length) >= explanation.Length;
        Check("Complete hero explanation remains in actual native text layout", fullRange);
        Check("Hero full text range fits its assigned native width", glyphs.All(rect => rect.X >= -0.01 && rect.Right <= copy.Bounds.Width + 0.01));
        var rangeBounds = glyphs.Select(rect => new Rect(bounds.X + copy.Padding.Left + rect.X, bounds.Y + copy.Padding.Top + rect.Y, rect.Width, rect.Height)).ToArray();
        Check("Hero explanatory glyph ranges do not intersect observed-status column", rangeBounds.All(rect => !rect.Intersects(column)));
        var rootBounds = new Rect(root.Bounds.Size);
        Check("Actual hero text remains within measured Home root width", rangeBounds.All(rect => rect.Right <= rootBounds.Right + 0.01));
        var report = new
        {
            scope = "Actual native source-linked BrowserApplication.Render, anonymous existing Home projection and TextLayout geometry; not browser or full visible readability acceptance.",
            sourcePath, width, height, horizontalScroll = scroll.HorizontalScrollBarVisibility.ToString(), diagnosticPropertyMutation = diagnostic,
            checks, failures = failed, sections, nativeClientSize = window.ClientSize, nativeRoot = root.Bounds,
            scrollExtent = scroll.Extent, scrollViewport = scroll.Viewport,
            heroCopy = new { text = copy.Text, wrapping = copy.TextWrapping.ToString(), bounds, nativeWidth = copy.Bounds.Width, clipToBounds = copy.ClipToBounds,
                layoutWidth = layout.WidthIncludingTrailingWhitespace, layoutHeight = layout.Height, lineCount = layout.TextLines.Count, glyphs, rangeBounds },
            observedStatus = column
        };
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        File.WriteAllText(outputPath, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
        return failed;
    }
    finally { app.ResetPrivateContext(); window.Content = null; window.Close(); }
}, CancellationToken.None);
if (failures != 0) throw new InvalidOperationException($"Native Home glyph/layout failed {failures} assertions.");

public sealed class HomeGlyphApplication : Application
{
    public static AppBuilder BuildAvaloniaApp() => CuiNativeHost.ConfigureFonts(AppBuilder.Configure<HomeGlyphApplication>().UseSkia())
        .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false });
    public override void Initialize() => CuiNativeHost.InitialisePrimitiveTheme(this, "Home");
}
